#!/bin/bash
# EyeGuard install script
# Usage: ./install.sh [version]  (default: latest)

set -e

VERSION=${1:-latest}
REPO="lyloou/eyeguard"
BASE_URL="https://github.com/$REPO/releases/download/$VERSION"

echo "Installing EyeGuard $VERSION ..."

TMP=$(mktemp -d)
cd "$TMP"

# 下载打包zip
curl -L "$BASE_URL/V20260501130000.zip" -o eyeguard.zip

# 解压
unzip eyeguard.zip

# 安装 App
if [ -d "Release/EyeGuard.app" ]; then
  unzip -o "Release/EyeGuard.app.zip" -d /Applications/
fi

# 安装 CLI
if [ -f "Release/eyeguard" ]; then
  mkdir -p ~/.eyeguard/bin
  cp Release/eyeguard ~/.eyeguard/bin/
  chmod +x ~/.eyeguard/bin/eyeguard
fi

# 配置 PATH
SHELL_RC="$HOME/.zshrc"
if ! grep -q 'eyeguard/bin' "$SHELL_RC" 2>/dev/null; then
  echo 'export PATH="$HOME/.eyeguard/bin:$PATH"' >> "$SHELL_RC"
fi

echo ""
echo "Done! Run: source ~/.zshrc && eyeguard --help"
