# EyeGuard 护眼卫士

> macOS 菜单栏护眼提醒 App — 工作 30 分钟，休息 5 分钟

## 一键安装

```bash
curl -L https://github.com/lyloou/eyeguard/releases/download/v0.1.4/v0.1.4.zip | funzip | bash
```

然后重启终端或运行 `source ~/.zshrc`，输入 `eyeguard --help` 验证。

---

## 功能说明

- **状态栏倒计时** — 菜单栏实时显示工作/休息剩余时间
- **强制休息** — 休息时段不可跳过，保护眼睛
- **快捷键** — ⌘⇧E 继续工作、⌘⇧P 暂停计时
- **CLI 控制** — 命令行随时查看状态、调整设置

## CLI 命令

```bash
eyeguard status      # 查看状态
eyeguard start       # 开始工作
eyeguard pause       # 暂停
eyeguard resume      # 继续
eyeguard reset       # 重置
eyeguard rest-now    # 立即休息
eyeguard skip        # 跳过休息
eyeguard stats       # 今日统计
eyeguard settings    # 查看配置
eyeguard set-style <name>  # 切换样式
eyeguard launch      # 启动 App
eyeguard quit        # 退出 App
eyeguard dim         # 暗屏
eyeguard bright      # 亮屏
```

## 状态栏样式

| 样式 | 示例 |
|------|------|
| classic | `工作中 29:59` |
| minimal | `29:59` |
| emoji | `💼 29:59` |
| compact | `[29:59]` |
| bracket | `工作中 [29:59]` |
| star | `★ 29:59` |
| dots | `工作中 ●●●●○○○○○` |
| progressBar | `工作中 ████░░░░░░ 15m` |

切换样式：`eyeguard set-style <name>`

---

Built: 2026-05-01
